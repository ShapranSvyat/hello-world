from .http_method import http_method

__all__ = ("http_method",)
