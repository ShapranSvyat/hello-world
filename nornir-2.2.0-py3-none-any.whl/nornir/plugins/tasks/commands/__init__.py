from .command import command
from .remote_command import remote_command


__all__ = ("command", "remote_command")
