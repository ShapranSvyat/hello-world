
USE test;

CREATE TABLE flow_table(
	src_ip VARCHAR(15),
	src_port INT,
	dst_ip VARCHAR(15),
	dst_port INT,
	packets INT,
	bytes INT,
	stamp DATETIME
)

