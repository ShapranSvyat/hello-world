######
v0.2.3
######

2015-04-29

- fixes issue with importing syslog module on Windows
