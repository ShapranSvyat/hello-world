######
v0.3.2
######

2015-07-16

- fixes a problem with parsing the hostname value in the system module
