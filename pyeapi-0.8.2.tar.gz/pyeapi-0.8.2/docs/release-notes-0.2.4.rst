######
v0.2.4
######

2015-04-30

- adds required docs/description.rst for setup.py
