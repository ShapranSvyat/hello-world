######
v0.6.1
######

2016-03-04

(This is a hotfix release)

New Modules
^^^^^^^^^^^
* None

Enhancements
^^^^^^^^^^^^
* None

Fixed
^^^^^
* SR56181 - pyeapi 0.5.0 and 0.6.0 aren't able to execute commands with enable password (`88 <https://github.com/arista-eosplus/pyeapi/issues/88>`_)
    A regression was introduced in 0.5.0 which broke passing the enable password to the Node() object.
