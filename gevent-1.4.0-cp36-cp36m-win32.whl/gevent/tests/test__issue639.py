# Test idle
import gevent
gevent.sleep()
gevent.idle()
