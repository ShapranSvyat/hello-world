from distutils.version import StrictVersion

__all__ = ['VERSION']

VERSION = StrictVersion('0.29')
