##
# .documentation
##
r"""
See: `postgresql.documentation.index`
"""
__docformat__ = 'reStructuredText'
