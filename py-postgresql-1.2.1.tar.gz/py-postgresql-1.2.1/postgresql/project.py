'project information'

#: project name
name = 'py-postgresql'

#: IRI based project identity
identity = 'http://python.projects.postgresql.org/'

meaculpa = 'Python+Postgres'
contact = 'python-general@pgfoundry.org'
abstract = 'Driver and tools library for PostgreSQL'

version_info = (1, 2, 1)
version = '.'.join(map(str, version_info))
