"""
Python tools package.

Various extensions to the standard library.
"""
