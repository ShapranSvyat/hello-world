*******************
Similarity Measures
*******************

.. automodule:: networkx.algorithms.smallworld
.. autosummary::
   :toctree: generated/

   random_reference
   lattice_reference
   sigma
   omega
