**********
Efficiency
**********

.. automodule:: networkx.algorithms.efficiency
.. autosummary::
   :toctree: generated/

   efficiency
   local_efficiency
   global_efficiency
