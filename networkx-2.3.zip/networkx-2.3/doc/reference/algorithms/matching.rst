********
Matching
********

.. automodule:: networkx.algorithms.matching
.. autosummary::
   :toctree: generated/

   is_matching
   is_maximal_matching
   is_perfect_matching
   maximal_matching
   max_weight_matching
